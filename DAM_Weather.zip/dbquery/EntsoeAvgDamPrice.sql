CREATE TABLE "EntoseAvgDamPrice" (
    "datetime" DATETIME,
    "dam_price" DECIMAL(5,2),
    PRIMARY KEY ("datetime")
 )