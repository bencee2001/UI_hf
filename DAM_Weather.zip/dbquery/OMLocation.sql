CREATE TABLE "OMLocation" (
     "id" int,
     "latitude" DECIMAL(5,2),
     "longitude" DECIMAL(5,2),
	 PRIMARY KEY ("id")
 )