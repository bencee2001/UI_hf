CREATE TABLE "OMAvgWeather" (
    "datetime" DATETIME,
    "temperature" DECIMAL(7,4),
    "humidity" INT,
    PRIMARY KEY ("datetime")
 )